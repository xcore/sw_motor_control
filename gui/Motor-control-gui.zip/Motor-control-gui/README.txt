Motor control FOC interface
---------------------------

These files constitute the LabView based front end for the XMOS FOC demo application.

The interface will control two motors on one XMOS FOC demo, and can display graphs of
some of the run time parameters.

In order to run the software, the following LabView runtime environment will need to
be downloaded and installed:

http://joule.ni.com/nidu/cds/view/p/id/1101/lang/en

It is the LabView Runtime Engine 8.6.

After installing the LabView engine, the application can be launched by running the
"XMOS Control.exe" application.

After starting it will ask for a communication type.  Unless the software has been
deliberately built to use the CAN interface, then the Ethernet interface should be
selected.  By default the IP address of the demonstration firmware will be 192.168.0.1.
This can be changed by modifying the firmware of the app_dsc_demo application.

